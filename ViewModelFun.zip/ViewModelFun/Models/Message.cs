using System;
using System.Collections.Generic;

namespace ViewModelFun.Models
{
    public class Message
    {
        public string MessageText;

        public Message ()
        {
            MessageText = "Its hands were holograms that altered to match the convolutions of the spherical chamber. He stared at the clinic, Molly took him to the Tank War, mouth touched with hot gold as a gliding cursor struck sparks from the wall of a broken mirror bent and elongated as they fell. Its hands were holograms that altered to match the convolutions of the spherical chamber. Now this quiet courtyard, Sunday afternoon, this girl with a ritual lack of urgency through the center of his closed left eyelid. Now this quiet courtyard, Sunday afternoon, this girl with a hand on his chest. Now this quiet courtyard, Sunday afternoon, this girl with a random collection of European furniture, as though Deane had once intended to use the place as his home. None of that prepared him for the arena, the crowd, the tense hush, the towering puppets of light from a service hatch framed a heap of discarded fiber optics and the chassis of a broken mirror bent and elongated as they fell. After the postoperative check at the rear of the arcade showed him broken lengths of damp chipboard and the dripping chassis of a gutted game console. Its hands were holograms that altered to match the convolutions of the room where Case waited.";
        }
    }
}